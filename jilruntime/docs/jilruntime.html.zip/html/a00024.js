var a00024 =
[
    [ "ctor", "a00024.html#a1b855102d7232f00f9a1401c48f1f459", null ],
    [ "cctor", "a00024.html#a585a069472415c61622cb741608833fe", null ],
    [ "dtor", "a00024.html#a843e962a057e7a3c3ec376e91143db4a", null ],
    [ "tostr", "a00024.html#a7a27ef19b4ad3a3dd2b5f0c9d642ff62", null ]
];