var a00024 =
[
    [ "numAlloc", "a00024.html#af7e0a640ef6d04d03a5056ec151f3b5f", null ],
    [ "numFree", "a00024.html#a79a5b977fd67718b0bb869d52df26ea1", null ],
    [ "bytesUsed", "a00024.html#ac836bfe17888193b63be44252709fc31", null ],
    [ "maxBytesUsed", "a00024.html#abff5f8106901d0ccf20c082500a1541e", null ],
    [ "numBuckets", "a00024.html#a9504228856e28e6f3941d001910d5556", null ],
    [ "bucketBytes", "a00024.html#a24b0dbc8adc780e3b89f8e1b60c54474", null ]
];