var a00032 =
[
    [ "type", "a00032.html#a47b29d25e319e97f6564811640d962d5", null ],
    [ "base", "a00032.html#a7f5486a79feb4aef41c1c9de10ce8c3f", null ],
    [ "family", "a00032.html#af97cc30513bcd624d0d98c89f6c0ce71", null ],
    [ "isNative", "a00032.html#a1b09aa4dc638049e82375f108555f169", null ],
    [ "offsetName", "a00032.html#a32766b1e939d075f04a1dbfe35321492", null ],
    [ "offsetVtab", "a00032.html#aed8470998446b2b6da53956355318464", null ],
    [ "sizeVtab", "a00032.html#a63beb2079098283d007514acab24d610", null ],
    [ "instanceSize", "a00032.html#a2de38476211299cae6121b2e3bfed580", null ],
    [ "interfaceVersion", "a00032.html#ae26304be0e24c40e0b8610260f46aacb", null ],
    [ "authorVersion", "a00032.html#acf7394dc68ab0556c19cc57d3cb66ae6", null ],
    [ "methodInfo", "a00032.html#a7ca481b830a5dd5f174d31e577455166", null ],
    [ "typeProc", "a00032.html#a020bd8922adeb40d7c429d863310607f", null ],
    [ "instance", "a00032.html#ad7ee6d327ee5e22a8758f5713c51dae6", null ],
    [ "typeNamePtr", "a00032.html#abccdd5376ec2e452f9b543ec02821079", null ]
];