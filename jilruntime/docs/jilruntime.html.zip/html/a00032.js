var a00032 =
[
    [ "pClassName", "a00032.html#afdb65e5e6419a4c303a4a0e3bff9ed70", null ],
    [ "typeProc", "a00032.html#acd4b4e62b2da810d1d230c67b54c8887", null ]
];