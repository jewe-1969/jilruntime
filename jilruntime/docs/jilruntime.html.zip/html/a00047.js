var a00047 =
[
    [ "JILAllocObject", "a00047.html#ae9e001d8f54d92faafc065f7e24c3a93", null ],
    [ "JILAllocObjectNoInit", "a00047.html#a097a296cc2498472f614ee8743860985", null ],
    [ "JILAllocArrayMulti", "a00047.html#ab41963d8c8cdceea0b491701326a6c8a", null ],
    [ "JILAllocString", "a00047.html#af3c748d600c49bbe38e9554aaf0d2e4e", null ],
    [ "JILAllocStringFromCStr", "a00047.html#a608e3727078443aaac91c951ef98408d", null ],
    [ "JILAllocDelegate", "a00047.html#a698f0b253b563159070a20602b8451c4", null ],
    [ "JILAllocClosure", "a00047.html#a2abe17c635a9f3a172bc8459de21ad56", null ],
    [ "JILFreeDelegate", "a00047.html#ae1108ba48b75de663c089315486adf18", null ],
    [ "JILAllocFactory", "a00047.html#a6eef36fce775d389a52a6dc09e66b543", null ]
];