var a00041 =
[
    [ "kErrorFormatDefault", "a00041.html#a0411cd49bb5b71852cecd93bcbf0ca2da76a63e2a898a81274077e5008723c063", null ],
    [ "kErrorFormatMS", "a00041.html#a0411cd49bb5b71852cecd93bcbf0ca2da9dc84a0a76d3f1a9cd278e87e350bdf9", null ]
];