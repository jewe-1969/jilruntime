var a00001 =
[
    [ "size", "a00001.html#a97d95f04b84c33ad4a1049473e3e3896", null ],
    [ "maxSize", "a00001.html#ae2d0de95ee3cd8fb0f0c47e00a2accd8", null ],
    [ "ppHandles", "a00001.html#a34dbd09a08682c6bb204960bb56808c6", null ],
    [ "pState", "a00001.html#a2b9def4cd614d99dc35aa1975ce3c07f", null ]
];