var a00057 =
[
    [ "JIL_INSERT_DEBUG_CODE", "a00057.html#a4b99bdb543d403bdaba014fcca990920", null ],
    [ "JILGetErrException", "a00057.html#a41aa61346f3f125539232ecd28ba75e0", null ],
    [ "JILGetErrDataStackPointer", "a00057.html#abfabb0bfb9c9db4149021cfdb38c19eb", null ],
    [ "JILGetErrCallStackPointer", "a00057.html#a827c6cb2ce27aef0c74ed09c712f4b7c", null ],
    [ "JILGetErrProgramCounter", "a00057.html#ae719102601adccbeaa58aeb9a22e252a", null ],
    [ "JILGetDataHandle", "a00057.html#a0c402bab2bd64c3ce258f47c5641ac81", null ],
    [ "JILGetRuntimeHandle", "a00057.html#a3c1af289603460e4c5bfb134a7215c07", null ],
    [ "JILClearExceptionState", "a00057.html#abcf3569014c2ecbf965423d8a3b486f9", null ],
    [ "JILGetTraceFlag", "a00057.html#a0d474d4af2aa780a998007edfe2577d2", null ],
    [ "JILSetTraceFlag", "a00057.html#a4b32639ef9223970ced066dca9da5c79", null ]
];