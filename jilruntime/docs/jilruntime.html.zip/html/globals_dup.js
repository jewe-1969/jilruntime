var globals_dup =
[
    [ "d", "globals.html", null ],
    [ "j", "globals_j.html", null ],
    [ "k", "globals_k.html", null ],
    [ "n", "globals_n.html", null ],
    [ "t", "globals_t.html", null ]
];