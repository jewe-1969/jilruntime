var globals_dup =
[
    [ "d", "globals.html", null ],
    [ "f", "globals_f.html", null ],
    [ "h", "globals_h.html", null ],
    [ "j", "globals_j.html", null ],
    [ "k", "globals_k.html", null ],
    [ "n", "globals_n.html", null ],
    [ "o", "globals_o.html", null ],
    [ "s", "globals_s.html", null ],
    [ "t", "globals_t.html", null ]
];