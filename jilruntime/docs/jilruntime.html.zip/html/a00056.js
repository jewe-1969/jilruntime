var a00056 =
[
    [ "JCLCompile", "a00056.html#a6a6284d2420d4ca7d44dca35fb455c50", null ],
    [ "JCLLoadAndCompile", "a00056.html#aba5f4fa5ecd30be153275876dc1e342a", null ],
    [ "JCLLink", "a00056.html#a200e1eb960b89174b74822375ab4247f", null ],
    [ "JCLGetErrorText", "a00056.html#a54f4cb11c73c410e856df24c0ba2b09d", null ],
    [ "JCLCompileAndRun", "a00056.html#aa0d7d44be596a3bd68fe28d3ab0fa589", null ],
    [ "JCLAddAnonFunction", "a00056.html#a6d7c698542a42e6648b8631df43a9010", null ],
    [ "JCLSetFatalErrorHandler", "a00056.html#a2f83dafacdf4982d2b3279caa2888677", null ],
    [ "JCLSetGlobalOptions", "a00056.html#aff18b1ee47078eef3952333bfb8898bb", null ],
    [ "JCLGenerateBindings", "a00056.html#a44f5239bc3e6baef9ac7231d5edb0fb3", null ],
    [ "JCLGenerateDocs", "a00056.html#a4b19068b0a7a7abfcbccbe112bfd2b39", null ],
    [ "JCLExportTypeInfo", "a00056.html#a6697665bc973c1117b27101e39d96bc5", null ],
    [ "JCLAddImportPath", "a00056.html#afe1065da0f697a95c78cd30c0ea180a2", null ],
    [ "JCLForwardClass", "a00056.html#ae2651bcdd28aeaed2db17bbca9415510", null ],
    [ "JCLImportClass", "a00056.html#aaed4f08b7cbbe63ec0320c741e8f9c44", null ],
    [ "JCLImportAllNatives", "a00056.html#ae22b6cd89adc132b0f87fa1c53ed46b2", null ],
    [ "JCLFreeCompiler", "a00056.html#accaa56e0bdb73995e2538e2c66b24508", null ]
];