var a00003 =
[
    [ "cnkMagic", "a00003.html#afce0dcbd77dd6d4e4c030088c6325f08", null ],
    [ "cnkSize", "a00003.html#a13ac1aaaab5ea6bfc3687018a9122aeb", null ],
    [ "cnkTypeSegSize", "a00003.html#a8f45f52f1d3ee2c8fb33e6a77edb314b", null ],
    [ "cnkDataSegSize", "a00003.html#acbfe60c8e5ff595d5c5e12e60c787da4", null ],
    [ "cnkCodeSegSize", "a00003.html#a6a8c3e9b0323d74f83d3c9188fd1b892", null ],
    [ "cnkFuncSegSize", "a00003.html#aed54df29329b7ac2b08ac55fca955e8e", null ],
    [ "cnkCStrSegSize", "a00003.html#ae46b8c5a8c5451b8ed354b78cc1df1fb", null ],
    [ "cnkSymTabSize", "a00003.html#a5699495a83684a49b254628cf96b150e", null ]
];