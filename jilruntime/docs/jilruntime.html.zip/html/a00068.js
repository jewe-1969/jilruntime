var a00068 =
[
    [ "DEFINESCRIPT", "a00068.html#ad507e88f132f79c628edafa21b53cfa3", null ],
    [ "TAG", "a00068.html#abf7ebd2c6f0af802f2f128e80189667e", null ],
    [ "JIL_USE_LITTLE_ENDIAN", "a00068.html#ad3a6463e3fa561bf624c11a8a72dd5ba", null ],
    [ "JIL_USE_LOCAL_FILESYS", "a00068.html#a4f1923997c671450d8fd4cfe2998d1cc", null ],
    [ "JIL_USE_BINDING_CODEGEN", "a00068.html#a4421a25fb0067c724fd01f01c44f19ce", null ],
    [ "JIL_USE_HTML_CODEGEN", "a00068.html#a86d3284b4608dea6c859761acb64b9fb", null ],
    [ "JIL_NO_FPRINTF", "a00068.html#a556fc6f3d8dc57cf645631e6e26bd4a2", null ],
    [ "JIL_USE_INSTRUCTION_COUNTER", "a00068.html#a7eb408e71200a5fef6efd15fb7ffccd0", null ],
    [ "JIL_RUNTIME_CHECKS", "a00068.html#a1dbf948b176c06950de3a8135f7d4e27", null ],
    [ "JIL_TRACE_RELEASE", "a00068.html#aa311ac7c51ff8008536d0177d43a22cf", null ],
    [ "JIL_STRING_POOLING", "a00068.html#af86fac44dd40cd5825ce83192df34760", null ],
    [ "JIL_MACHINE_NO_64_BIT", "a00068.html#a24cb43484cbba0d86a170dd2558e3e26", null ]
];