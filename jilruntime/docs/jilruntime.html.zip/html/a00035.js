var a00035 =
[
    [ "typeID", "a00035.html#a7f437c2b98250f37caf8c7bbb208d445", null ],
    [ "userData", "a00035.html#a495e98970e159ebb7d3a7aef18f6bfee", null ],
    [ "pState", "a00035.html#a495712072d511335c38d8a6f299b9b6d", null ]
];