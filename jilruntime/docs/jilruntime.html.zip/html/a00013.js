var a00013 =
[
    [ "type", "a00013.html#a4929acae7556012e1b07dc4939bed4c2", null ],
    [ "flags", "a00013.html#aa97be4f2357cf044389d99c1b89c7c33", null ],
    [ "refCount", "a00013.html#a6ed2f19b2ecdb0035a633aa25b9780a4", null ],
    [ "reserved", "a00013.html#a9bf78cdd846be1a054bffb7dde2dd46e", null ],
    [ "data", "a00013.html#abd29e5bdba5037eae0b2ab0ebd4c8430", null ]
];