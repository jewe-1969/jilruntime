var a00013 =
[
    [ "type", "a00013.html#ab969d443613254fdf5658c0d3877bc23", null ],
    [ "flags", "a00013.html#ad982ec5d050787ae15b0a0e9e55d5dfe", null ],
    [ "refCount", "a00013.html#a6ed2f19b2ecdb0035a633aa25b9780a4", null ],
    [ "data", "a00013.html#ae7f5bf677de81408fbc9428d5ffa7ff5", null ]
];