var a00079 =
[
    [ "JIL_PRODUCT_VERSION", "a00079.html#a8f4fb79996bbccba9a72adb06505973a", null ],
    [ "JIL_LIBRARY_VERSION", "a00079.html#a2abe75708b0289e480fe320e067f8eeb", null ],
    [ "JIL_COMPILER_VERSION", "a00079.html#ad79879e4f83717019776b296449784c8", null ],
    [ "JIL_MACHINE_VERSION", "a00079.html#af8e6206d82086503a2c787a4faaf4a2d", null ],
    [ "JIL_TYPE_INTERFACE_VERSION", "a00079.html#abc903fa7419aa88741adc2e86afe8c8d", null ]
];