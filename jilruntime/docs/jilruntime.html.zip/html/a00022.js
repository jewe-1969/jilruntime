var a00022 =
[
    [ "opCode", "a00022.html#ab8976442e2d5f43e1ad08406cff45b36", null ],
    [ "instrSize", "a00022.html#ad6bf7826e83f54159d025ed5b7a97a1f", null ],
    [ "numOperands", "a00022.html#aad976f98b5d59d913708ebed5fe94663", null ],
    [ "opType", "a00022.html#a54176c8d4f25363ce2d087afefa4654d", null ],
    [ "name", "a00022.html#a8ba5ad72d0d155c1e1ffe14940387f44", null ]
];