var a00006 =
[
    [ "type", "a00006.html#ad258419a6f05b2c7f61cae3f90068e40", null ],
    [ "index", "a00006.html#a38558fd01d43621744cbc0b6acf3ea87", null ],
    [ "data", "a00006.html#a69cd033345d2fe9ec56b7f7ece1eac50", null ]
];