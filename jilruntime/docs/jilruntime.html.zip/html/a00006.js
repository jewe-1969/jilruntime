var a00006 =
[
    [ "type", "a00006.html#a41109884acb37647e279e9dcf65a919b", null ],
    [ "index", "a00006.html#a38558fd01d43621744cbc0b6acf3ea87", null ],
    [ "data", "a00006.html#ad698f906c1b18f1b941d19edf677e731", null ]
];