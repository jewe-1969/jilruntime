var a00031 =
[
    [ "pPrev", "a00031.html#a51ae9102217feaaf5035dcca1e831f43", null ],
    [ "pNext", "a00031.html#a0ef8210e972c9fdcb82de981a768b7c1", null ],
    [ "sizeName", "a00031.html#ac09dc53e28270b087e216693d841dd12", null ],
    [ "pName", "a00031.html#aaa57f0ee6eed4c70029156c65dba8238", null ],
    [ "sizeData", "a00031.html#a0f54b7e87ab121a7a0a9590589df86f4", null ],
    [ "pData", "a00031.html#ad2982ad66059bffca3ebdfaf9fc50fdb", null ]
];