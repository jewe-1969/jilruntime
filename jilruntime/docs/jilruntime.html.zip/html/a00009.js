var a00009 =
[
    [ "pStream", "a00009.html#a3f7feb61648d1236d13b6d5aab42b9d2", null ],
    [ "pState", "a00009.html#a6cde6f4d4757cc9367fd29886efb469c", null ]
];