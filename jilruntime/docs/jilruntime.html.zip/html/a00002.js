var a00002 =
[
    [ "vmDataStackPointer", "a00002.html#a00eb6b930d7eb7ca71e3ce60f5dfe867", null ],
    [ "vmCallStackPointer", "a00002.html#a72c3705a13efc7994a549884b8254bc9", null ],
    [ "vmProgramCounter", "a00002.html#ac74f36229a566b2f7b8573490cd218ce", null ],
    [ "vmppRegister", "a00002.html#ac73bcbd052bf8eecd77032ab9a8e8c40", null ],
    [ "vmppDataStack", "a00002.html#a58b70329814507c171323580939eff27", null ],
    [ "vmpCallStack", "a00002.html#a3547d3a8afef5f4186cd8388de0b448a", null ],
    [ "vmpYieldContext", "a00002.html#a2223f9a90ca08d3de6d1f50ec4d14b76", null ]
];