var a00004 =
[
    [ "stackSize", "a00004.html#a0e30b1b16fefeb81c3aa402dabfb8ed3", null ],
    [ "ppStack", "a00004.html#a11a68fff4c61d56edc49779b9e24cf2d", null ]
];