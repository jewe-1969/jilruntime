var globals_func =
[
    [ "j", "globals_func.html", null ],
    [ "n", "globals_func_n.html", null ]
];