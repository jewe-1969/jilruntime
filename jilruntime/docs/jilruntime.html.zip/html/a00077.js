var a00077 =
[
    [ "JILInitTypeInfoSegment", "a00077.html#aaf865b6d228d378aeda7beca0bd4bd06", null ],
    [ "JILNewTypeInfo", "a00077.html#a2be13f292c235470483dc78aaded77d4", null ],
    [ "JILFindTypeInfo", "a00077.html#a92db2e23e4b55c28e556a6a7f659b94a", null ],
    [ "JILDestroyTypeInfoSegment", "a00077.html#ad2259dcebd074bdf7a50c6fef9f0fc5a", null ]
];