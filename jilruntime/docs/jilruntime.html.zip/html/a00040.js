var a00040 =
[
    [ "kLocalAuto", "a00040.html#a726ca809ffd3d67ab4b8476646f26635a91646199e6bfad1946293b34f8d7d0d6", null ],
    [ "kLocalRegister", "a00040.html#a726ca809ffd3d67ab4b8476646f26635acf919472c7a733dd19dcd2cc035d3171", null ],
    [ "kLocalStack", "a00040.html#a726ca809ffd3d67ab4b8476646f26635ab86783f45c2593afc45826c542799b33", null ],
    [ "kErrorFormatDefault", "a00040.html#a0411cd49bb5b71852cecd93bcbf0ca2da76a63e2a898a81274077e5008723c063", null ],
    [ "kErrorFormatMS", "a00040.html#a0411cd49bb5b71852cecd93bcbf0ca2da9dc84a0a76d3f1a9cd278e87e350bdf9", null ]
];