var a00061 =
[
    [ "JILHandleInt", "a00019.html", null ],
    [ "JILHandleFloat", "a00018.html", null ],
    [ "JILHandleString", "a00022.html", null ],
    [ "JILHandleArray", "a00014.html", null ],
    [ "JILHandleObject", "a00021.html", null ],
    [ "JILHandleNObject", "a00020.html", null ],
    [ "JILHandleContext", "a00015.html", null ],
    [ "JILHandleDelegate", "a00017.html", null ],
    [ "JILAddRef", "a00061.html#a99bbf632a11da205a71791c3326784a3", null ],
    [ "JILRelease", "a00061.html#a17d6a82c43c514e03e980fd2ad944ada", null ],
    [ "JILInitHandles", "a00061.html#a4cc7dc05e2d709f136790dfe049b9b56", null ],
    [ "JILGetNewHandle", "a00061.html#a90076e0c9f4d4a6df430f0240d11eaa8", null ],
    [ "JILFindHandleIndex", "a00061.html#a3f63a0d51ffc7aacea9ececbcba60524", null ],
    [ "JILDestroyHandles", "a00061.html#ae89036e510dd2d54d24cc47648651c29", null ],
    [ "JILCopyHandle", "a00061.html#add0932bb4a1520680b6f0c58c2ea6609", null ],
    [ "JILCopyValueType", "a00061.html#a61eb7e1f2d60aea0166cdc47774f63d0", null ],
    [ "JILCreateWeakRef", "a00061.html#aa9b39e09fc4e11cb9fe6ad1c76dc4b39", null ],
    [ "JILMarkHandle", "a00061.html#afe8212695b06c404affc778921db3707", null ],
    [ "JILDestroyObject", "a00061.html#a088e3bbd9b5e400279d01d3e607ba944", null ],
    [ "JILCreateException", "a00061.html#acbfb6f6630bfbe7054da85802d3f4d40", null ]
];