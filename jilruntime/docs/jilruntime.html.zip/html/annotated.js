var annotated =
[
    [ "JILArray", "a00001.html", "a00001" ],
    [ "JILContext", "a00002.html", "a00002" ],
    [ "JILFunctionTable", "a00003.html", "a00003" ],
    [ "JILState", "a00004.html", "a00004" ],
    [ "JILString", "a00005.html", "a00005" ],
    [ "JILVersionInfo", "a00006.html", "a00006" ],
    [ "NStringMatch", "a00007.html", "a00007" ]
];