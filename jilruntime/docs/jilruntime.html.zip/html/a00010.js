var a00010 =
[
    [ "type", "a00010.html#ad0a3cd8e91db1f546f8837737802451e", null ],
    [ "flags", "a00010.html#acb074575969c45241ec3ce4164a07521", null ],
    [ "codeAddr", "a00010.html#a146079dd823784a1d6f5968af82ad788", null ],
    [ "codeSize", "a00010.html#abd687d5e5455ba0fcb1f79d9df0d263c", null ],
    [ "args", "a00010.html#af37be0d018a1fd453469b4f87e656a02", null ],
    [ "memberIdx", "a00010.html#ad396d4f17bd11cf4573b3b7723efe4d2", null ],
    [ "offsetName", "a00010.html#a71de62c09e621ff516c6467fbb8a500e", null ]
];