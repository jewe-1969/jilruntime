var dir_db02c1fed38bf4964b962c28c04a52b2 =
[
    [ "jilarray.c", "a00016.html", "a00016" ],
    [ "jilarray.h", "a00017.html", "a00017" ],
    [ "jilstring.c", "a00018.html", "a00018" ],
    [ "jilstring.h", "a00019.html", "a00019" ]
];