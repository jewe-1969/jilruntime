var a00034 =
[
    [ "typeID", "a00034.html#a7f437c2b98250f37caf8c7bbb208d445", null ],
    [ "userData", "a00034.html#a495e98970e159ebb7d3a7aef18f6bfee", null ],
    [ "pState", "a00034.html#a495712072d511335c38d8a6f299b9b6d", null ]
];