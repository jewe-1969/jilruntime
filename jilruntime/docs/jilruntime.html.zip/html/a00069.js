var a00069 =
[
    [ "JILCreateLong", "a00069.html#a333b9a9da7029dea51457912f1c55750", null ],
    [ "JILCreateFloat", "a00069.html#ae828df3fe52afbee635a70f5e53306e2", null ],
    [ "JILCreateString", "a00069.html#a1f6a8acd64c733968690fffd949d88ec", null ],
    [ "JILCreateFunction", "a00069.html#a2e52b21f69f9f93401e15af4bb5ade69", null ],
    [ "JILGetFunctionByName", "a00069.html#a4de81e042aa7e87641517de53a598107", null ],
    [ "JILGetFunctionByAddr", "a00069.html#aa940d6a99fad8445e3d3f780ca21143a", null ],
    [ "JILGetFunctionByIndex", "a00069.html#ab563b88ac4ed4d00f7d40257659af894", null ],
    [ "JILGetNumFunctions", "a00069.html#a01371cb168256b4e89d99cb516fb8dbf", null ],
    [ "JILGetFunctionInfo", "a00069.html#a3798f079e0b379b24c2edf87d418a7d9", null ],
    [ "JILSetFunctionAddress", "a00069.html#a94e1d89c46506aeb27b7f8cadf7d353c", null ],
    [ "JILCreateType", "a00069.html#a04139712c3405a25849a0410df7b3398", null ],
    [ "JILSetClassInstanceSize", "a00069.html#a4b29d619e10711c7013faa7a2a5a51c4", null ],
    [ "JILSetClassVTable", "a00069.html#aaab7b3548c2c41efe15b1a9ffca44886", null ],
    [ "JILSetClassMethodInfo", "a00069.html#a539863a503dc405ea5013188869befbf", null ],
    [ "JILSetGlobalObjectSize", "a00069.html#abdb72b523ceb105c24e61d0aab1ff701", null ],
    [ "JILSetMemory", "a00069.html#a145fac0e0b542ed30dc9b8366f140a1e", null ],
    [ "JILGetMemory", "a00069.html#a65bcae6f82545000542e2c6d7edda2ed", null ],
    [ "JILCreateRestorePoint", "a00069.html#ab02a3b0eaa92a24b685e8db1e8b3b254", null ],
    [ "JILGotoRestorePoint", "a00069.html#ae6bc89c03548d04ae0970e68448ea43a", null ],
    [ "JILGetCodeLength", "a00069.html#aa82d7164c3ee3d003889264bc67519a7", null ]
];