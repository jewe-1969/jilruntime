var a00025 =
[
    [ "reMagic", "a00025.html#aa63cef95654df549570c82f7d41097fd", null ],
    [ "reUsedTypeSegSize", "a00025.html#a4af29f95fd9d033955ca45438ff7c031", null ],
    [ "reUsedDataSegSize", "a00025.html#a7188c3d61a14f91b42ed479f244e7287", null ],
    [ "reUsedCodeSegSize", "a00025.html#a50e7902196525f9abac82c5850ab5070", null ],
    [ "reUsedCStrSegSize", "a00025.html#ad119443ca19be8d9001a020d3c053b48", null ],
    [ "reUsedSymTabSize", "a00025.html#a391a4bf772aaa757e8bcaf3c4e54fc93", null ]
];