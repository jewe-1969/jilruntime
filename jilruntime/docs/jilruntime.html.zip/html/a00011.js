var a00011 =
[
    [ "size", "a00011.html#a8a0440c582859ee13379b515d68a9c5a", null ],
    [ "func", "a00011.html#adda7382b77c1b20fbf54a6f6c362c36e", null ]
];