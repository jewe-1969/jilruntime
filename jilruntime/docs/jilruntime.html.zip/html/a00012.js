var a00012 =
[
    [ "pUserPtr", "a00012.html#a1b47a6e5a95ab8d466b5360c2102bb83", null ],
    [ "eventProc", "a00012.html#a050e95029cff271e5896791c8e21a335", null ],
    [ "pNext", "a00012.html#a8c21476a2d8a6bbd9546f4cbb9db6a14", null ]
];